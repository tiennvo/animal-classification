#Cài đặt thư viện : pip install -r requirements.txt
#Data trong dogscats
#Train lại theo ý của bạn trong train.ipynb
#Sử dụng giao diện GUI bằng cách chạy python predict.py(Cài đặt đầy đủ thư viện trước khi chạy nên dùng anaconda)
#model_trained là model đã train trước vs độ chính xác 97% trong GUI sử dụng model này
#Lưu ý chỉnh sửa đường dẫn model phù hợp để tránh bị lỗi